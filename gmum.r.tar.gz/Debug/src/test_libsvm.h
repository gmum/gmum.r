#ifndef TEST_LIBSVM_H
#define TEST_LIBSVM_H

#include <R.h>

void test_libsvm();

#endif
