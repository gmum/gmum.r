#include "svm_flow_factory.h"
#include <vector>

// SVMFlowFactory | At the moments returns empty vector<hanlder>
std::vector<SVMHandler*> SVMFlowFactory::createSVMFlow(
		SVMConfiguration config) {
	std::vector<SVMHandler*> handlers;
	return handlers;
	// TODO
}
