gmum.r
======
R package for our group's models.

For more information and useful links please check wiki.

For actual version remember to switch to the dev branch.
